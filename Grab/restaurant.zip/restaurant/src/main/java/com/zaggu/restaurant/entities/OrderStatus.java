package com.zaggu.restaurant.entities;

public enum OrderStatus {
    PLACED, ACCEPTED, PREPARING, READY, OUT_FOR_DELIVERY, DELIVERED, CANCELLED
}