package com.zaggu.restaurant.Services;


import com.zaggu.restaurant.entities.MenuItem;
import com.zaggu.restaurant.Repositories.MenuItemRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RestaurantService {
    private final MenuItemRepository menuItemRepository;

    public List<MenuItem> getMenuItems(Long restaurantId) {
        return menuItemRepository.findByRestaurantId(restaurantId);
    }
}