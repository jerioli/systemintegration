package com.zaggu.restaurant.Services;

public class MenuItemServices {
    
}
