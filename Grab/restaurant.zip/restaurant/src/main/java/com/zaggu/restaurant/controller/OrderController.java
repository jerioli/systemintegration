package com.zaggu.restaurant.controller;




import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zaggu.restaurant.Services.OrderService;
import com.zaggu.restaurant.entities.Order;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    @PostMapping("/place")
    public ResponseEntity<Order> placeOrder(
            @RequestParam Long customerId,
            @RequestParam Long restaurantId,
            @RequestParam List<Long> menuItemIds) {
        
        Order order = orderService.placeOrder(customerId, restaurantId, menuItemIds);
        return ResponseEntity.ok(order);
    }

    // ✅ Accept JSON request body instead of URL parameters
    @PostMapping("/place/json")
    public ResponseEntity<Order> placeOrder(@RequestBody OrderRequest orderRequest) {
        Order order = orderService.placeOrder(
                orderRequest.getCustomerId(),
                orderRequest.getRestaurantId(),
                orderRequest.getMenuItemIds()
        );
        return ResponseEntity.ok(order);
    }
    

    @GetMapping
    public ResponseEntity<List<Order>> getAllOrders() {
        return ResponseEntity.ok(orderService.getAllOrders());
    }
}
